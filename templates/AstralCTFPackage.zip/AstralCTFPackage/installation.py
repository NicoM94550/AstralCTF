import os
Check = True
while Check:
	adminEmail = raw_input("Please enter an admin email: ")
	emailCheck = raw_input("Please confirm the email: ")
	if adminEmail == emailCheck:
		Check = False
	else:
		print("The emails do not match. Please try again")
secretSauce = str(raw_input("Please enter a secret hash(should be long and complex, don't bother memorizing): "))
try:
	os.system("sudo apt-get upgrade")
except:
	pass
try:
	os.system("sudo apt-get update")
except:
	pass
try:
	os.system("sudo apt-get --yes --force-yes install apache2 mysql-client mysql-server")
except:
	pass
try:
	os.system("sudo apt-get --yes --force-yes install libapache2-mod-wsgi")
except:
	pass
try:
	os.system("sudo apt-get --yes --force-yes install python-pip")
except:
	pass
try:
	os.system("pip install --upgrade pip")
except:
	pass
try:
	os.system("pip install Flask")
except:
	pass
try:
	os.system("sudo apt-get --yes --force-yes install python-dev libmysqlclient-dev")
except:
	pass
try:
	os.system("pip install MySQL-python")
except:
	pass
try:
	os.system("pip install wtforms")
except:
	pass
try:
	os.system("pip install passlib")
except:
	pass
os.system("sudo a2enmod wsgi")
os.system("sudo mkdir /var/www/FlaskApp")
os.system("ifconfig -a > ipaddr.txt")
ipAddr = open('ipaddr.txt','r').read().split('inet addr:')[1].split(' ')[0]
toWrite = ("""<VirtualHost *:80>
	ServerName %s
	ServerAdmin %s
	WSGIScriptAlias / /var/www/FlaskApp/flaskapp.wsgi
	<Directory /var/www/FlaskApp/FlaskApp/>
		Order allow,deny
		Allow from all
	</Directory>
	Alias /static /var/www/FlaskApp/FlaskApp/static
	<Directory /var/www/FlaskApp/FlaskApp/static/>
		Order allow,deny
		Allow from all
	</Directory>
	ErrorLog ${APACHE_LOG_DIR}/error.log
	LogLevel warn
	CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>""" % (ipAddr,adminEmail))
os.system("touch /etc/apache2/sites-available/FlaskApp.conf")
File = open('/etc/apache2/sites-available/FlaskApp.conf','w+')
File.write(toWrite)
File.close()
os.system("sudo a2ensite FlaskApp")
os.system("service apache2 reload")
os.system("touch /var/www/FlaskApp/flaskapp.wsgi")
toWrite = ("""#!/usr/bin/python
import sys
import logging
logging.basicConfig(stream=sys.stderr)
sys.path.insert(0,"/var/www/FlaskApp/")

from FlaskApp import app as application
application.secret_key = '%s'""" % secretSauce)
File = open('/var/www/FlaskApp/flaskapp.wsgi','w')
File.write(toWrite)
File.close()
os.system("service apache2 restart")
print("Now you must enter your MySQL password.")
os.system("mysql -u root -p -e 'CREATE DATABASE AstralCTF;'")
os.system("mysql -u root -p AstralCTF -e 'CREATE TABLE teams (teamname VARCHAR(20), captain_firstname VARCHAR(50), captain_lastname VARCHAR(50));'")
os.system("mysql -u root -p AstralCTF -e 'CREATE TABLE valid_hashes (hash CHAR(10) PRIMARY KEY, status INT(1));'")
os.system("mysql -u root -p AstralCTF -e 'CREATE TABLE problems (problem VARCHAR(50), status INT(1) DEFAULT 0);'")
Check = True
while Check:
	mysqlpasswd = raw_input("Please enter your mysqlpasswd: ")
	mysqlcheck = raw_input("Please confirm the password: ")
	if mysqlpasswd == mysqlcheck:
		Check = False
	else:
		print("The passwords do not match. Please try again")
File = open('AstralCTF/dbconnect.py','r')
Data = File.read().replace("MYSQLPASSWD",mysqlpasswd)
File.close()
File = open('AstralCTF/dbconnect.py','w')
File.write(Data)
File.close()
os.system("mv AstralCTF /var/www/FlaskApp")
os.system("mv /var/www/FlaskApp/AstralCTF /var/www/FlaskApp/FlaskApp")
os.system("sudo rm -rf ipaddr.txt")
os.system("service apache2 restart")
print("Setup finished.")
print("Now please add the files in the folder 'AstralCTF' to /var/www/FlaskApp/FlaskApp")
print("Once done, navigate to the 'Problems' folder and run 'addproblem.py'")
print("After adding as many problems as you would like navigate back to /var/www/FlaskApp/FlaskApp and run 'setup.py'")
print("The strings printed out by 'setup.py' are used to register teams, don't lose them!")
print("Once that is done running execute the command 'service apache2 restart'")
print("You can now navigate to the IP address of your server on any computer and the competition will load.")
print("To reset teams and score, run 'setup.py'")
print("To add a problem, run 'addproblem.py'")
print("To delete all problems, execute the command 'sudo rm -rf *.txt' in the /var/www/FlaskApp/FlaskApp/Problems folder.")
print("Your IP address is: %s" % ipAddr)