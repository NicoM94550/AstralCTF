from flask import Flask, render_template, request, url_for, redirect, flash, request
from content_management import Header
from content_management import activeProblems
from content_management import Error
from content_management import hashProblem
from dbconnect import connection
from MySQLdb import escape_string as thwart
from wtforms import Form, TextField, PasswordField, BooleanField, validators
from passlib.hash import sha256_crypt
import gc

PAGE_LIST = Header()
ERROR_PAGE = Error()
Conversion = hashProblem()

app = Flask(__name__)

@app.route(PAGE_LIST[0][1])
def homepage():
	try:
		PAGE_LIST_TEMP = Header()
		PAGE_LIST_TEMP.remove(PAGE_LIST[0])
		return render_template(PAGE_LIST[0][2],PAGE_LIST = PAGE_LIST_TEMP, TITLE = PAGE_LIST[0][3], HEADER = PAGE_LIST[0][4])
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)

class RegistrationForm(Form):
		attempted_hash = PasswordField("Hash", [validators.Length(min=10, max=10)])
		team_name = TextField("Team Name", [validators.Length(min=1, max=20)])
		captain_firstname = TextField("Captain's Firstname", [validators.Length(min=1, max=20)])
		captain_lastname = TextField("Captain's Lastname", [validators.Length(min=1, max=20)])
		accept_tos = BooleanField("I promise that I will not use any knowledge gained from this competition for malicious purposes and that I will play fair without intterupting the experience of others.")

class AddHash(Form):
		hashtoadd = TextField("Hash to Add", [validators.Length(min=10, max=10)])
		admin = PasswordField("Admin Password")

class PrintTables(Form):
		admin = PasswordField("Admin Password")
		
class AnswerProblem(Form):
		teamHash = PasswordField("Team Hash", [validators.Length(min=10,max=10)])
		answer = PasswordField("Answer")
		
@app.route(PAGE_LIST[1][1], methods = ['GET', 'POST'])
def registerteam():
	try:
		PAGE_LIST_TEMP = Header()
		PAGE_LIST_TEMP.remove(PAGE_LIST[1])
		form = RegistrationForm(request.form)
		if request.method == "POST" and form.validate():
			attempted_hash =  form.attempted_hash.data
			team_name = form.team_name.data
			captain_firstname = form.captain_firstname.data
			captain_lastname = form.captain_lastname.data
			c, conn = connection()
			x = c.execute("SELECT * FROM valid_hashes WHERE hash = '%s' AND status = 1" % thwart(attempted_hash))
			if int(x) == 0:
				error = ("That hash is either invalid or has been used. Please try again")
				return render_template(PAGE_LIST[1][2], PAGE_LIST = PAGE_LIST_TEMP, TITLE = PAGE_LIST[1][3], HEADER = PAGE_LIST[1][4], form = form, error = error)
			else:
				x = c.execute("SELECT * FROM teams WHERE teamname = '%s'" % thwart(team_name))
				y = c.execute("SELECT * FROM teams WHERE captain_firstname = '"+thwart(captain_firstname)+"' AND captain_lastname = '"+thwart(captain_lastname)+"'")
				if int(x) == 0 and int(y) == 0:
					c.execute("UPDATE valid_hashes SET status=0 WHERE hash='%s'" % thwart(attempted_hash))
					conn.commit()
					toExecute = "INSERT INTO teams (teamname, captain_firstname, captain_lastname, hashused) VALUES ('"+thwart(team_name)+"', '"+thwart(captain_firstname)+"', '"+thwart(captain_lastname)+"', '"+thwart(attempted_hash)+"')"
					c.execute(toExecute)
					conn.commit()
					c.close()
					conn.close()
					gc.collect()
					error = ("Thank you for registering your team! Best of luck.")
				elif int(x) > 0:
					error = ("Team already exists!")
				elif int(y) > 0:
					error = (captain_firstname + " " + captain_lastname + " is already a captain!")
				return render_template(PAGE_LIST[1][2], PAGE_LIST = PAGE_LIST_TEMP, TITLE = PAGE_LIST[1][3], HEADER = PAGE_LIST[1][4], form = form, error = error)
		return render_template(PAGE_LIST[1][2], PAGE_LIST = PAGE_LIST_TEMP, TITLE = PAGE_LIST[1][3], HEADER = PAGE_LIST[1][4], form = form)
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)

@app.route('/problems/<problem>', methods = ['GET', 'POST'])
def problemPage(problem):
	try:
		error = None
		PAGE_LIST_TEMP = Header()
		PAGE_LIST_TEMP.remove(PAGE_LIST[2])
		ProblemData = open(('%s' % Conversion[problem]),'r').read().split("///")
		ProblemName = ProblemData[0]
		ProblemText = ProblemData[1]
		ProblemAnswer = ProblemData[2]
		ProblemHash = ProblemData[3]
		ProblemPoints = ProblemData[4]
		Link = ProblemHash
		form = AnswerProblem(request.form)
		Hint = "/problems/%s/hint" % Link
		if request.method == "POST" and form.validate():
			teamhash =  form.teamHash.data
			answer = sha256_crypt.encrypt(str(form.answer.data))
			if not sha256_crypt.verify(ProblemAnswer, answer):
				error = ("That is not the right answer!")
				return render_template("problemPage.html", PAGE_LIST = PAGE_LIST_TEMP, TITLE = ProblemName, form = form, ProblemText = ProblemText, error = error, Link = Link, PROBLEMS = PAGE_LIST[2], HINT = Hint)
			elif sha256_crypt.verify(ProblemAnswer, answer):
				c, conn = connection()
				y = c.execute("SELECT * FROM teams WHERE hashused = ('%s')" % thwart(teamhash))
				if y == 0:
					error = "Team does not exist!"
					return render_template("problemPage.html", PAGE_LIST = PAGE_LIST_TEMP, TITLE = ProblemName, form = form, ProblemText = ProblemText, error = error, Link = Link, PROBLEMS = PAGE_LIST[2], HINT = Hint)
				x = c.execute("SELECT * FROM teams WHERE hashused = ('%s') AND %s = (0)" % (thwart(teamhash), thwart(ProblemName)))
				if int(x) == 1:
					c.execute("UPDATE problems SET status = (1) WHERE problem = '%s'" % thwart(ProblemName))
					conn.commit()
					c.execute("UPDATE teams SET %s = (1) WHERE hashused = '%s'" % (thwart(ProblemName), thwart(teamhash)))
					conn.commit()
					c.execute("UPDATE teams SET points = (points + %s) WHERE hashused = '%s'" % (thwart(ProblemPoints), thwart(teamhash)))
					conn.commit()
					error = ("Points Awarded!")
					PROBLEM_DATA = open("var/www/FlaskApp/FlaskApp/Problems/PROBLEM_LIST.txt","r").readlines()
					PROBLEM_NAMES = [x.replace("\n","").split("///")[4] for x in sorted(PROBLEM_DATA)]
					INDEX = PROBLEM_NAMES.index(ProblemName)
					if (INDEX+1) == len(PROBLEM_NAMES):
						pass
					else:
						NEXT_PROBLEM = PROBLEM_NAMES[INDEX+1]
						TEMP = c.execute("SELECT * FROM problems WHERE problem = '%s' and status = (0)" % thwart(NEXT_PROBLEM))
						if int(TEMP) == 1:
							c.execute("UPDATE problems SET status = (1) WHERE problem = '%s'" % thwart(NEXT_PROBLEM))
							conn.commit()
					c.close()
					conn.close()
					gc.collect()
				elif int(x) == 0:
					error = ("Points have already been awarded to this team.")
					c.close()
					conn.close()
					gc.collect()
				return render_template("problemPage.html", PAGE_LIST = PAGE_LIST_TEMP, TITLE = ProblemName, form = form, ProblemText = ProblemText, error = error, Link = Link, PROBLEMS = PAGE_LIST[2], HINT = Hint)
		return render_template("problemPage.html", PAGE_LIST = PAGE_LIST_TEMP, TITLE = ProblemName, form = form, ProblemText = ProblemText, error = error, Link = Link, PROBLEMS = PAGE_LIST[2], HINT = Hint)
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)
		
@app.route('/problems/<problem>/hint', methods = ['POST', 'GET'])
def Hint(problem):
	try:
		error = None
		PAGE_LIST_TEMP = Header()
		PAGE_LIST_TEMP.remove(PAGE_LIST[2])
		ProblemData = open(('%s' % Conversion[problem]),'r').read().split("///")
		ProblemHint = ProblemData[5]
		PROBLEM = "/problems/%s" % problem
		return render_template('Hint.html', PROBLEM = PROBLEM, HINT = ProblemHint, PAGE_LIST = PAGE_LIST_TEMP)
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)
		
@app.route(PAGE_LIST[2][1])
def problems():
	try:		
		ACTIVE_PROBLEMS = activeProblems()
		toRemove = []
		for x in ACTIVE_PROBLEMS.keys():
			if len(ACTIVE_PROBLEMS[x]) == 0:
				toRemove.append(x)
		for x in toRemove:
			del ACTIVE_PROBLEMS[x]
		PAGE_LIST_TEMP = Header()
		PAGE_LIST_TEMP.remove(PAGE_LIST[2])
		return render_template(PAGE_LIST[2][2], PAGE_LIST = PAGE_LIST_TEMP, ACTIVE_PROBLEMS = ACTIVE_PROBLEMS, TITLE = PAGE_LIST[2][3], HEADER = PAGE_LIST[2][4])
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)

@app.route(PAGE_LIST[3][1])
def scoreboard():
	try:
		c, conn = connection()
		c.execute("SELECT teamname,points FROM teams;")
		conn.commit()
		TEAM_DATA = c.fetchall()
		conn.close()
		gc.collect()
		TEAM_DATA_TEMP = []
		TEAM_DATA = sorted([[x[1],x[0]] for x in TEAM_DATA])[::-1]
		PAGE_LIST_TEMP = Header()
		PAGE_LIST_TEMP.remove(PAGE_LIST[3])
		return render_template(PAGE_LIST[3][2], PAGE_LIST = PAGE_LIST_TEMP, TITLE = PAGE_LIST[3][3], HEADER = PAGE_LIST[3][4], TEAM_DATA = TEAM_DATA)
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)

@app.route(PAGE_LIST[4][1])
def references():
	try:
		PAGE_LIST_TEMP = Header()
		PAGE_LIST_TEMP.remove(PAGE_LIST[4])
		return render_template(PAGE_LIST[4][2], PAGE_LIST = PAGE_LIST_TEMP, TITLE = PAGE_LIST[4][3], HEADER = PAGE_LIST[4][4])
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)

@app.route(PAGE_LIST[5][1])
def about():
	try:
		PAGE_LIST_TEMP = Header()
		PAGE_LIST_TEMP.remove(PAGE_LIST[5])
		return render_template(PAGE_LIST[5][2], PAGE_LIST = PAGE_LIST_TEMP, TITLE = PAGE_LIST[5][3], HEADER = PAGE_LIST[5][4])
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)

@app.errorhandler(404)
def page_not_found(e):
	try:
		PAGE_LIST_TEMP = Header()
		return render_template(ERROR_PAGE, ERROR_TYPE = e)
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)

@app.route('/admin')		
def adminpanel():
	try:
		return render_template('adminpanel.html', PAGE_LIST = PAGE_LIST)
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)

@app.route('/admin/addhash', methods = ['GET', 'POST'])
def addhash():
	try:
		error = None
		form = AddHash(request.form)
		if request.method == "POST" and form.validate():
			hashtoadd =  form.hashtoadd.data
			enteredpassword = sha256_crypt.encrypt(str(form.admin.data))
			adminPassword = open("/var/www/FlaskApp/FlaskApp/admin.txt",'r').read().replace("\n","")
			if sha256_crypt.verify(adminPassword,enteredpassword):
				c, conn = connection()
				if int(c.execute("SELECT * FROM valid_hashes WHERE hash = ('%s')" % thwart(hashtoadd))) > 0:
					conn.close()
					gc.collect()
					error = "Hash already in use!"
					return render_template('addhash.html', PAGE_LIST = PAGE_LIST, form = form, error = error)
				c.execute("INSERT INTO valid_hashes (hash, status) VALUES ('%s', 1)" % thwart(hashtoadd))
				conn.commit()
				c.close()
				conn.close()
				gc.collect()
				error = ("Hash added.")
				return render_template('addhash.html', PAGE_LIST = PAGE_LIST, form = form, error = error)
			else:
				error = ("Invalid password.")
				return render_template('addhash.html', PAGE_LIST = PAGE_LIST, form = form, error = error)
		return render_template('addhash.html', PAGE_LIST = PAGE_LIST, form = form, error = error)
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)
		
@app.route('/admin/printtables', methods = ['GET', 'POST'])
def printtables():
	try:
		error = None
		form = PrintTables(request.form)
		if request.method == "POST" and form.validate():
			enteredpassword = sha256_crypt.encrypt(str(form.admin.data))
			adminPassword = open("/var/www/FlaskApp/FlaskApp/admin.txt",'r').read().replace("\n","")
			if sha256_crypt.verify(adminPassword,enteredpassword):
				c, conn = connection()
				c.execute("SELECT * FROM valid_hashes")
				conn.commit()
				valid_hashes = c.fetchall()
				c.execute("SELECT * FROM teams")
				conn.commit()
				teams = c.fetchall()
				c.close()
				conn.close()
				gc.collect()
				error = [valid_hashes,teams]
				return render_template('printtables.html', PAGE_LIST = PAGE_LIST, form = form, error = error)
			else:
				error = ("Invalid password.")
				return render_template('printtables.html', PAGE_LIST = PAGE_LIST, form = form, error = error)
		return render_template('printtables.html', PAGE_LIST = PAGE_LIST, form = form, error = error)
	except Exception as e:
		return render_template(ERROR_PAGE, ERROR_TYPE = e)

		
if __name__ == "__main__":
	app.run()
