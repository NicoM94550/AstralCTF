import random
from passlib.hash import sha256_crypt
Alphabet = list("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
ProblemName = True
while ProblemName is True:
	try:
		ProblemName = str(raw_input("What is the problem's name(no spaces please)?\n..."))
	except Exception:
		print("Please enter a string.")
ProblemText = True
while ProblemText is True:
	try:
		ProblemText = str(raw_input("What is the problem text?\n..."))
	except Exception:
		print("Please enter a string.")
ProblemAnswer = True
while ProblemAnswer is True:
	try:
		ProblemAnswer = str(raw_input("What is the problem's answer?\n..."))
	except Exception:
		print("Please enter a string.")
ProblemPoints = True
while ProblemPoints is True:
	try:
		ProblemPoints = int(raw_input("What is the problem's point value?\n..."))
	except Exception:
		print("Please enter an integer.")
ProblemCatagory = True
while ProblemCatagory is True:
	try:
		ProblemCatagory = str(raw_input("What is the problem's catagory?\n..."))
	except Exception:
		print("Please enter a string.")
ProblemHint = True
while ProblemHint is True:
	try:
		ProblemHint = str(raw_input("What is the problem's hint(or type 'No hint')?\n..."))
	except Exception:
		print("Please enter a string.")
ProblemUnlock = True
while ProblemUnlock is True:
	try:
		ProblemUnlock = int(raw_input("What is the problem's unlock level(integer, 1 unlocks first, then 2 and on)?\n..."))
	except Exception:
		print("Please enter an integer.")
HashLink = ""
for x in range(20):
	HashLink += Alphabet[random.randint(0,61)]
File = open('MASTER.txt','a')
toMaster = ProblemCatagory + "///" + str(ProblemPoints) + "///" + HashLink + "\n"
File.write(toMaster)
File.close()
File = open(("%s.txt" % ProblemName),'w')
toProblemName = ProblemName + "///" + ProblemText + "///" + ProblemAnswer + "///" + HashLink + "///" + str(ProblemPoints) + "///" + ProblemHint
File.write(toProblemName)
File.close()
File = open('PROBLEM_LIST.txt','a')
toList = str(ProblemUnlock) + "///" + str(ProblemPoints) + "///" + HashLink + "///" + ProblemCatagory + "///" + ProblemName + "\n"
File.write(toList)
File.close()
