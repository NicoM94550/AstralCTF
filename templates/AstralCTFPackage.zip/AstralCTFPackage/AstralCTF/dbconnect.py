import MySQLdb

def connection():
	conn = MySQLdb.connect(host="localhost", user="root", passwd="MYSQLPASSWD", db="AstralCTF")
	c = conn.cursor()
	return c,conn
