import gc
from dbconnect import connection

def Header():
	PAGE_LIST = [["Homepage","/","main.html","AstralCTF","AstralCTF"],["Register Team","/register","register-team.html","Team Registration","Register a Team"],["Problems","/problems","problems.html","Problems","Problems"],["Scoreboard","/scoreboard","scoreboard.html","Scoreboard","Scoreboard"],["Reference Guide","/references","references.html","Reference Guide","Reference Guide"],["About","/about","about.html","About","About AstralCTF"]]	
	#["Button Name","Link","html filename","Title","Header"]
	return(PAGE_LIST)
def problemNames():
	PROBLEM_RAW = open('Problems/PROBLEM_LIST.txt','r').readlines()
	for i,x in enumerate(PROBLEM_RAW):
		PROBLEM_RAW[i] = x.replace("\n","")
		if PROBLEM_RAW[i] == "":
			PROBLEM_RAW.remove(PROBLEM_RAW[i])
		else:
			PROBLEM_RAW[i] = PROBLEM_RAW[i].split("///")
	PROBLEM_RAW = sorted(PROBLEM_RAW)
	for x,i in enumerate(PROBLEM_RAW):
		PROBLEM_RAW[x][0] = PROBLEM_RAW[x][4]
	PROBLEM_LIST = [x[0] for x in PROBLEM_RAW]
	return(PROBLEM_LIST)

def activeProblems():
	PROBLEM_RAW = open('var/www/FlaskApp/FlaskApp/Problems/PROBLEM_LIST.txt','r').readlines()
	for i,x in enumerate(PROBLEM_RAW):
		PROBLEM_RAW[i] = x.replace("\n","")
	PROBLEM_RAW = [x.split("///") for x in PROBLEM_RAW]
	problemNames = [x[4] for x in PROBLEM_RAW]
	c, conn = connection()
	c.execute("SELECT * FROM problems WHERE status = (1)")
	conn.commit()
	activeproblems = c.fetchall()
	conn.close()
	gc.collect()
	Categories = getCategories()
	ACTIVE_PROBLEMS = {}
	CategoriesToDict = [[x,[]] for x in Categories]
	for x in activeproblems:
		x = PROBLEM_RAW[problemNames.index(x[0])]
		CategoriesToDict[Categories.index(x[3])][1].append([x[1],("/problems/%s" % x[2])])
	for x in CategoriesToDict:
		if len(x[1]) == 0:
			pass
		else:
			ACTIVE_PROBLEMS[x[0]] = x[1]
	return(ACTIVE_PROBLEMS)

def problems():
	PROBLEM_MASTER = open('/var/www/FlaskApp/FlaskApp/Problems/MASTER.txt','r').readlines()
	PROBLEM_MASTER = [x.split("///") for x in PROBLEM_MASTER]#[0]=category,[1]=points,[2]=hashlink
	Categories = getCategories()
	CategoriesToDict = [[x,[]] for x in Categories]
	PROBLEMS = {}
	for x in PROBLEM_MASTER:
		CategoriesToDict[Categories.index(x[0])][1].append([x[1],x[2]])
	for x in CategoriesToDict:
		PROBLEMS[x[0]] = x[1]
	return(PROBLEMS)

def hashProblem():
	PROBLEM_RAW = open('/var/www/FlaskApp/FlaskApp/Problems/PROBLEM_LIST.txt','r').readlines()#
	PROBLEM_RAW = [x.replace("\n","").split("///") for x in PROBLEM_RAW]
	Conversion = {}
	for x in PROBLEM_RAW:
		Conversion[x[2]] = ('/var/www/FlaskApp/FlaskApp/Problems/%s.txt' % x[4])
	return(Conversion)

def Error():
	ERROR_PAGE = "errorHandler.html"
	return(ERROR_PAGE)

def getCategories():
	PROBLEM_RAW = open('/var/www/FlaskApp/FlaskApp/Problems/PROBLEM_LIST.txt','r').readlines()
	PROBLEM_RAW = [x.replace("/n","").split("///") for x in PROBLEM_RAW]
	Categories_RAW = [x[3] for x in PROBLEM_RAW]
	Categories = []
	for x in Categories_RAW:
		if x not in Categories:
			Categories.append(x)
	return(Categories)

