from dbconnect import connection
from content_management import problemNames
import random
import gc

Categories = ["Crypto1", "RE1", "Stego1", "PC1","Trivia1"]
Alphabet = list("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
Problems = problemNames()
c, conn = connection()
c.execute("DROP TABLE teams")
conn.commit()
c.execute("DROP TABLE valid_hashes")
conn.commit()
c.execute("DROP TABLE problems")
conn.commit()
c.execute("CREATE TABLE valid_hashes (hash CHAR(10), status INT(1))")
conn.commit()
c.execute("CREATE TABLE teams (teamname VARCHAR(20), captain_firstname VARCHAR(50), captain_lastname VARCHAR(50), hashused CHAR(10), points VARCHAR(5) NOT NULL DEFAULT 0)")
conn.commit()
c.execute("CREATE TABLE problems (problem VARCHAR(50), status INT(1) NOT NULL DEFAULT 0)")
conn.commit()
for x in Problems:
	c.execute("ALTER TABLE teams ADD %s VARCHAR(50) NOT NULL DEFAULT 0" % x)
	conn.commit()
	c.execute("INSERT INTO problems (problem, status) VALUES ('%s',0)" % x)
	conn.commit()
numUsers = True
while numUsers is True:
	try:
		numUsers = int(input("How many users will be playing?\n..."))
	except Exception:
		print("Please enter an integer.")
Hashes = []
for x in range(numUsers):
	toAdd = ""
	for i in range(10):
		toAdd += Alphabet[random.randint(0,61)]
	c.execute("INSERT INTO valid_hashes (hash, status) VALUES ('%s', 1)" % toAdd)
	conn.commit()
	Hashes.append(toAdd)
"""
for x in Categories:
	c.execute("UPDATE problems SET status=1 WHERE problem='%s'" % x)
	conn.commit()
"""
toUnlock = open('Problems/PROBLEM_LIST.txt','r').readlines()
for i,x in enumerate(toUnlock):
	toUnlock[i] = x.replace("\n","").split("///")
for x in toUnlock:
	if x[0] == "1":
		c.execute("UPDATE problems SET status=1 WHERE problem='%s'" % x[4])
		conn.commit()
conn.close()
gc.collect()
print Hashes
