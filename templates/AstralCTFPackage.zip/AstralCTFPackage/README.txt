CREATED BY NICOLAS MACCHIONI
For a manual installation follow the steps outlined in this file. 
For an automatic installation execute 'installation.py' on the server.
For 'installation.py' to run make sure you have and run it with Python2.7
If Python2.7 is not on your server try:
	sudo apt-get update
	sudo apt-get upgrade
	sudo apt-get install python2.7
If website does not appear or throws an error after following these steps, run setup again.
If help is required contact NicoM94550@yahoo.com with Subject Line "AstralCTF Help" and he will get back to you ASAP.
SETUP:
1. Get somewhere to run Ubuntu Server
2. cd /
3. sudo apt-get upgrade
4. sudo apt-get update
5. cd /etc/ssh
6. sudo nano sshd_config
7. find the line that has TCPKeepAlive and add under it
	-"ClientAliveInterval 30"
	-"ClientAliveCountMax 99999"
8. service ssh restart
9. sudo apt-get install apache2 mysql-client mysql-server
10. sudo apt-get install libapache2-mod-wsgi
11. sudo a2enmod wsgi
12. cd /
13. cd /var/www
14. sudo mkdir FlaskApp
15. cd FlaskApp
16. sudo mkdir FlaskApp(Yes, a second one)
17. cd FlaskApp
18. sudo apt-get install python-pip; pip install --upgrade pip
19. sudo pip install virtualenv
20. sudo virtualenv venv
21. source venv/bin/activate
22. deactivate
23. pip install Flask
24. sudo nano /etc/apache2/sites-available/FlaskApp.conf(then add in it)
	-"<VirtualHost *:80>
                ServerName YOUR-IP-ADDRESS(can be found using ifconfig)
                ServerAdmin ADMIN-EMAIL(shown on 500 Server Error page)
                WSGIScriptAlias / /var/www/FlaskApp/flaskapp.wsgi
                <Directory /var/www/FlaskApp/FlaskApp/>
                        Order allow,deny
                        Allow from all
                </Directory>
                Alias /static /var/www/FlaskApp/FlaskApp/static
                <Directory /var/www/FlaskApp/FlaskApp/static/>
                        Order allow,deny
                        Allow from all
                </Directory>
                ErrorLog ${APACHE_LOG_DIR}/error.log
                LogLevel warn
                CustomLog ${APACHE_LOG_DIR}/access.log combined
	  </VirtualHost>"
25. sudo a2ensite FlaskApp
26. service apache2 reload
27. cd /var/www/FlaskApp
28. sudo nano flaskapp.wsgi(then add in it)
	-"#!/usr/bin/python
	  import sys
	  import logging
	  logging.basicConfig(stream=sys.stderr)
	  sys.path.insert(0,"/var/www/FlaskApp/")

	  from FlaskApp import app as application
	  application.secret_key = 'ADD-A-RANDOM-SECRET-KEY-HERE'"
29. service apache2 restart
30. take contents of AstralCTF folder and add them to /var/www/FlaskApp/FlaskApp
31. service apache2 restart
32. sudo apt-get install python-dev libmysqlclient-dev
33. pip install MySQL-python
34. pip install wtforms
35. pip install passlib
36. mysql --user=root -p
	- enter password you assigned earlier
37. CREATE DATABASE AstralCTF;
38. exit;
39. service apache2 restart
40. Now continue to "TO ADD A PROBLEM" section

**********
TO ADD A PROBLEM:
1. Navigate to /var/www/FlaskApp/FlaskApp/Problems
2. python addproblem.py
3. follow on-screen instructions
4. Continue to "TO START A NEW COMPETITION" section
**********
TO START A NEW COMPETITION:
1. Navigate to /var/www/FlaskApp/FlaskApp
2. python setup.py
3. THE STRINGS PRINTED OUT ARE THE HASHES USED TO MAKE TEAMS! DON'T LOSE THESE!
4. Continue to "TO CHANGE ADMIN PASSWORD" section
**********
TO CHANGE ADMIN PASSWORD:
1. Navigate to /var/www/FlaskApp/FlaskApp
2. change text in admin.txt
3. that text is now the admin password